<?php
session_start();
if (!isset($_SESSION['id_usuario'])) {
    header('Location: login.php');
    exit();
}

require_once '../config/Conexion.php'; // Asegúrate de que esté correcto.

// CRUD para gestionar usuarios y roles
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        $nombre = $_POST['nombre_usuario'];
        $correo = $_POST['correo'];
        $puntos = $_POST['puntos'];
        $rol = $_POST['id_rol'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO usuarios (nombre_usuario, correo, puntos, id_rol, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('ssiss', $nombre, $correo, $puntos, $rol, $password);
        $stmt->execute();
    }
    if (isset($_POST['delete'])) {
        $id = $_POST['id_usuario'];
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id_usuario = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
    }
    if (isset($_POST['update'])) {
        $id = $_POST['id_usuario'];
        $nombre = $_POST['nombre_usuario'];
        $correo = $_POST['correo'];
        $puntos = $_POST['puntos'];
        $rol = $_POST['id_rol'];

        $stmt = $conn->prepare("UPDATE usuarios SET nombre_usuario = ?, correo = ?, puntos = ?, id_rol = ? WHERE id_usuario = ?");
        $stmt->bind_param('ssisi', $nombre, $correo, $puntos, $rol, $id);
        $stmt->execute();
    }
}

// Obtener todos los usuarios
$result = $conn->query("SELECT * FROM usuarios");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../assets/librerias/estilos_crud.css">
</head>
<body>
    <h2>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre_usuario']); ?></h2>
    <a href="logout.php">Cerrar Sesión</a>
    
    <!-- Menú de navegación -->
    <nav>
        <ul>
            <li><a href="dashboard_login_crud.php">Usuarios</a></li>
            <li><a href="dashboard_recetas_crud.php">Recetas</a></li>
        </ul>
    </nav>

    <h3>Gestión de Usuarios y Roles</h3>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre_usuario" required>
        <label>Correo:</label>
        <input type="email" name="correo" required>
        <label>Puntos:</label>
        <input type="number" name="puntos" required>
        <label>Rol:</label>
        <select name="id_rol" required>
            <option value="1">Administrador</option>
            <option value="2">Usuario</option>
        </select>
        <label>Contraseña:</label>
        <input type="password" name="password" required>
        <button type="submit" name="create">Crear Usuario</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Puntos</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id_usuario']; ?></td>
                    <td><?php echo $row['nombre_usuario']; ?></td>
                    <td><?php echo $row['correo']; ?></td>
                    <td><?php echo $row['puntos']; ?></td>
                    <td><?php echo $row['id_rol'] == 1 ? 'Administrador' : 'Usuario'; ?></td>
                    <td>
                        <form method="POST" style="display:inline-block;">
                            <input type="hidden" name="id_usuario" value="<?php echo $row['id_usuario']; ?>">
                            <button type="submit" name="delete">Eliminar</button>
                        </form>
                        <form method="POST" style="display:inline-block;">
                            <input type="hidden" name="id_usuario" value="<?php echo $row['id_usuario']; ?>">
                            <input type="text" name="nombre_usuario" value="<?php echo $row['nombre_usuario']; ?>" required>
                            <input type="email" name="correo" value="<?php echo $row['correo']; ?>" required>
                            <input type="number" name="puntos" value="<?php echo $row['puntos']; ?>" required>
                            <select name="id_rol" required>
                                <option value="1" <?php echo $row['id_rol'] == 1 ? 'selected' : ''; ?>>Administrador</option>
                                <option value="2" <?php echo $row['id_rol'] == 2 ? 'selected' : ''; ?>>Usuario</option>
                            </select>
                            <button type="submit" name="update">Actualizar</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
